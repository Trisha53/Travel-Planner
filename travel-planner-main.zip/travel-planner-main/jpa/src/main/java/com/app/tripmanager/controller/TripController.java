package com.app.tripmanager.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.app.tripmanager.model.Trip;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TripController {

    

}
