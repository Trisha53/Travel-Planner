package com.app.tripmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripManagerApplication.class, args);
	}

}
